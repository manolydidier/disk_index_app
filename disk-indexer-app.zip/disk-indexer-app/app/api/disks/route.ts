import { NextResponse } from 'next/server';
import { DiskStatus } from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { generateNextDiskCode } from '@/lib/disk-code';
import { diskCreateSchema } from '@/lib/validators';

export const runtime = 'nodejs';

export async function GET() {
  const disks = await prisma.disk.findMany({
    orderBy: { code: 'asc' },
    include: {
      _count: {
        select: {
          entries: { where: { deletedAt: null } },
          activities: { where: { acknowledgedAt: null } }
        }
      }
    }
  });

  return NextResponse.json(disks);
}

export async function POST(request: Request) {
  const payload = await request.json();
  const parsed = diskCreateSchema.safeParse(payload);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const code = parsed.data.code ?? (await generateNextDiskCode());

  const disk = await prisma.disk.create({
    data: {
      code,
      name: parsed.data.name,
      rootPath: parsed.data.rootPath,
      description: parsed.data.description,
      status: parsed.data.status ?? DiskStatus.ACTIVE
    }
  });

  return NextResponse.json(disk, { status: 201 });
}
