'use client';

import { useMemo, useState } from 'react';
import { Search } from 'lucide-react';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { formatBytes, truncateMiddle } from '@/lib/utils';

type DiskOption = {
  id: string;
  code: string;
  name: string;
};

type SearchResult = {
  id: string;
  name: string;
  fullPath: string;
  extension: string | null;
  entryType: 'FILE' | 'FOLDER';
  modifiedAt: string | null;
  size: string | null;
  disk: {
    id: string;
    code: string;
    name: string;
    status: string;
  };
};

export function SearchClient({ disks }: { disks: DiskOption[] }) {
  const [query, setQuery] = useState('');
  const [diskId, setDiskId] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);

  const subtitle = useMemo(() => {
    if (!diskId) return 'Tous les disques indexés';
    const disk = disks.find((item) => item.id === diskId);
    return disk ? `${disk.code} — ${disk.name}` : 'Filtre actif';
  }, [diskId, disks]);

  async function runSearch() {
    setLoading(true);
    try {
      const params = new URLSearchParams({ q: query });
      if (diskId) params.set('diskId', diskId);
      const response = await fetch(`/api/search?${params.toString()}`);
      const data = (await response.json()) as SearchResult[];
      setResults(data);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recherche globale</CardTitle>
        <CardDescription>{subtitle}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-3 lg:grid-cols-[1fr_240px_auto]">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Nom de fichier, extension, dossier, chemin..." />
          <select
            className="h-10 rounded-md border bg-background px-3 text-sm"
            value={diskId}
            onChange={(e) => setDiskId(e.target.value)}
          >
            <option value="">Tous les disques</option>
            {disks.map((disk) => (
              <option key={disk.id} value={disk.id}>
                {disk.code} — {disk.name}
              </option>
            ))}
          </select>
          <Button onClick={runSearch} disabled={!query || loading}>
            <Search className="h-4 w-4" />
            {loading ? 'Recherche...' : 'Rechercher'}
          </Button>
        </div>

        <div className="rounded-xl border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nom</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Chemin exact</TableHead>
                <TableHead>Disque</TableHead>
                <TableHead>Taille</TableHead>
                <TableHead>Modifié le</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {results.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground">
                    Aucun résultat.
                  </TableCell>
                </TableRow>
              ) : (
                results.map((result) => (
                  <TableRow key={result.id}>
                    <TableCell className="font-medium">{result.name}</TableCell>
                    <TableCell>
                      <Badge variant="outline">{result.entryType === 'FILE' ? 'Fichier' : 'Dossier'}</Badge>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{truncateMiddle(result.fullPath, 60, 30)}</TableCell>
                    <TableCell>{result.disk.code}</TableCell>
                    <TableCell>{result.size ? formatBytes(Number(result.size)) : '-'}</TableCell>
                    <TableCell>
                      {result.modifiedAt ? format(new Date(result.modifiedAt), 'dd MMM yyyy HH:mm', { locale: fr }) : '-'}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
