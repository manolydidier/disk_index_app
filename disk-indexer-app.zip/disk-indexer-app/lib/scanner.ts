import { access, lstat, opendir } from 'fs/promises';
import path from 'path';
import {
  ActivityType,
  DiskStatus,
  EntryType,
  type FileEntry,
  type Prisma,
  ScanStatus,
  ScanType
} from '@prisma/client';
import { prisma } from '@/lib/prisma';
import { buildDiskTreeResponse } from '@/lib/tree';

type DiskRecord = {
  id: string;
  code: string;
  name: string;
  rootPath: string;
  status: DiskStatus;
};

type ScannedNode = {
  entryType: EntryType;
  name: string;
  relativePath: string;
  fullPath: string;
  extension: string | null;
  size: bigint | null;
  modifiedAt: Date | null;
  inode: string | null;
  fingerprint: string | null;
  metadata: Prisma.InputJsonValue;
  parentRelativePath: string | null;
};

type ScanDiff = {
  added: ScannedNode[];
  modified: Array<{ before: FileEntry; after: ScannedNode }>;
  renamed: Array<{ before: FileEntry; after: ScannedNode }>;
  deleted: FileEntry[];
  current: ScannedNode[];
};

export async function runDiskScan(diskId: string, scanType: ScanType = ScanType.DIFFERENTIAL) {
  const disk = await prisma.disk.findUnique({
    where: { id: diskId },
    select: {
      id: true,
      code: true,
      name: true,
      rootPath: true,
      status: true
    }
  });

  if (!disk) {
    throw new Error('Disque introuvable');
  }

  const scanJob = await prisma.scanJob.create({
    data: {
      diskId,
      scanType,
      status: ScanStatus.RUNNING,
      startedAt: new Date()
    }
  });

  try {
    await ensureDiskAccessible(disk);
    const scannedNodes = await scanFilesystem(disk);
    const existingEntries = await prisma.fileEntry.findMany({
      where: { diskId, deletedAt: null },
      orderBy: { relativePath: 'asc' }
    });

    const diff = computeDiff(existingEntries, scannedNodes);
    const result = await persistScanResult({ disk, diff, scanJobId: scanJob.id, scanType });

    return {
      jobId: scanJob.id,
      ...result
    };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Erreur de scan inconnue';

    await prisma.scanJob.update({
      where: { id: scanJob.id },
      data: {
        status: ScanStatus.FAILED,
        finishedAt: new Date(),
        errorMessage: message
      }
    });

    if (message.toLowerCase().includes('inaccessible') || message.toLowerCase().includes('non connecté') || message.toLowerCase().includes('not connected')) {
      await prisma.disk.update({
        where: { id: disk.id },
        data: { status: DiskStatus.DISCONNECTED }
      });

      await prisma.diskActivity.create({
        data: {
          diskId: disk.id,
          scanJobId: scanJob.id,
          activityType: ActivityType.DISK_STATUS,
          path: disk.code,
          details: {
            status: 'DISCONNECTED',
            message
          }
        }
      });
    }

    throw error;
  }
}

async function ensureDiskAccessible(disk: DiskRecord) {
  try {
    await access(disk.rootPath);
  } catch {
    throw new Error(`Le disque ${disk.code} est inaccessible ou non connecté.`);
  }
}

async function scanFilesystem(disk: DiskRecord) {
  const output: ScannedNode[] = [];

  async function walk(currentAbsolutePath: string, parentRelativePath: string | null) {
    const directory = await opendir(currentAbsolutePath);

    for await (const dirent of directory) {
      const absolutePath = path.join(currentAbsolutePath, dirent.name);
      if (dirent.isSymbolicLink()) {
        continue;
      }

      const stats = await lstat(absolutePath);
      const relativeFromRoot = path.relative(disk.rootPath, absolutePath);
      const normalizedRelative = normalizePath(relativeFromRoot);
      const fullPath = normalizedRelative ? `${disk.code}/${normalizedRelative}` : disk.code;
      const extension = dirent.isFile() ? path.extname(dirent.name).replace('.', '').toLowerCase() || null : null;
      const entryType = dirent.isDirectory() ? EntryType.FOLDER : EntryType.FILE;
      const currentParentRelative = normalizedRelative.includes('/')
        ? normalizedRelative.split('/').slice(0, -1).join('/')
        : parentRelativePath;

      output.push({
        entryType,
        name: dirent.name,
        relativePath: normalizedRelative,
        fullPath,
        extension,
        size: dirent.isFile() ? BigInt(stats.size) : null,
        modifiedAt: stats.mtime ? new Date(stats.mtime) : null,
        inode: typeof stats.ino === 'number' && stats.ino > 0 ? String(stats.ino) : null,
        fingerprint: buildFingerprint({
          entryType,
          extension,
          size: dirent.isFile() ? BigInt(stats.size) : null,
          modifiedAt: stats.mtime ? new Date(stats.mtime) : null,
          name: dirent.name
        }),
        metadata: {
          absolutePath,
          birthtime: stats.birthtime?.toISOString?.() ?? null,
          mode: stats.mode,
          isSymbolicLink: dirent.isSymbolicLink()
        },
        parentRelativePath: currentParentRelative ?? null
      });

      if (dirent.isDirectory()) {
        await walk(absolutePath, normalizedRelative);
      }
    }
  }

  await walk(disk.rootPath, null);

  return output.sort((a, b) => a.relativePath.localeCompare(b.relativePath, 'fr'));
}

function computeDiff(existingEntries: FileEntry[], scannedNodes: ScannedNode[]): ScanDiff {
  const existingByPath = new Map(existingEntries.map((entry) => [entry.relativePath, entry]));
  const existingByInode = buildUniqueLookup(existingEntries, (entry) => entry.inode);
  const existingByFingerprint = buildUniqueLookup(existingEntries, (entry) => entry.fingerprint);

  const matchedExistingIds = new Set<string>();
  const added: ScannedNode[] = [];
  const modified: Array<{ before: FileEntry; after: ScannedNode }> = [];
  const renamed: Array<{ before: FileEntry; after: ScannedNode }> = [];

  for (const node of scannedNodes) {
    const exactMatch = existingByPath.get(node.relativePath);
    if (exactMatch) {
      matchedExistingIds.add(exactMatch.id);
      if (hasEntryChanged(exactMatch, node)) {
        modified.push({ before: exactMatch, after: node });
      }
      continue;
    }

    const renameCandidate =
      (node.inode ? existingByInode.get(node.inode) : undefined) ??
      (node.fingerprint ? existingByFingerprint.get(node.fingerprint) : undefined);

    if (renameCandidate && !matchedExistingIds.has(renameCandidate.id)) {
      matchedExistingIds.add(renameCandidate.id);
      renamed.push({ before: renameCandidate, after: node });
      continue;
    }

    added.push(node);
  }

  const deleted = existingEntries.filter((entry) => !matchedExistingIds.has(entry.id));

  return {
    added,
    modified,
    renamed,
    deleted,
    current: scannedNodes
  };
}

async function persistScanResult(params: {
  disk: DiskRecord;
  diff: ScanDiff;
  scanJobId: string;
  scanType: ScanType;
}) {
  const { disk, diff, scanJobId, scanType } = params;
  const now = new Date();

  await prisma.$transaction(async (tx) => {
    for (const node of diff.added) {
      await tx.fileEntry.create({
        data: mapNodeToCreate(disk.id, node)
      });
    }

    for (const change of diff.modified) {
      await tx.fileEntry.update({
        where: { id: change.before.id },
        data: mapNodeToUpdate(nodeWithoutParent(change.after))
      });
    }

    for (const change of diff.renamed) {
      await tx.fileEntry.update({
        where: { id: change.before.id },
        data: mapNodeToUpdate(nodeWithoutParent(change.after))
      });
    }

    if (diff.deleted.length > 0) {
      await tx.fileEntry.updateMany({
        where: {
          id: { in: diff.deleted.map((entry) => entry.id) }
        },
        data: {
          deletedAt: now
        }
      });
    }

    const activeEntries = await tx.fileEntry.findMany({
      where: { diskId: disk.id, deletedAt: null },
      select: { id: true, relativePath: true }
    });
    const idByRelativePath = new Map(activeEntries.map((entry) => [entry.relativePath, entry.id]));

    for (const node of diff.current) {
      const entryId = idByRelativePath.get(node.relativePath);
      if (!entryId) continue;

      await tx.fileEntry.update({
        where: { id: entryId },
        data: {
          parentId: node.parentRelativePath ? (idByRelativePath.get(node.parentRelativePath) ?? null) : null,
          deletedAt: null
        }
      });
    }

    const freshEntries = await tx.fileEntry.findMany({
      where: { diskId: disk.id, deletedAt: null },
      orderBy: { relativePath: 'asc' }
    });

    const tree = buildDiskTreeResponse({
      diskId: disk.code,
      diskName: disk.name,
      rootPath: disk.rootPath,
      status: DiskStatus.ACTIVE,
      lastScan: now,
      entries: freshEntries
    });

    const activities = buildActivities(diff, disk.id, scanJobId);
    if (activities.length > 0) {
      await tx.diskActivity.createMany({ data: activities });
    }

    await tx.disk.update({
      where: { id: disk.id },
      data: {
        status: DiskStatus.ACTIVE,
        lastScanAt: now,
        lastFullScanAt: scanType === ScanType.FULL ? now : undefined,
        lastDiffScanAt: scanType === ScanType.DIFFERENTIAL ? now : undefined,
        lastActivityAt: activities.length > 0 ? now : undefined,
        lastTreeSnapshot: JSON.parse(JSON.stringify(tree))
      }
    });

    await tx.scanJob.update({
      where: { id: scanJobId },
      data: {
        status: ScanStatus.COMPLETED,
        finishedAt: now,
        summary: {
          added: diff.added.length,
          modified: diff.modified.length,
          renamed: diff.renamed.length,
          deleted: diff.deleted.length,
          totalIndexed: diff.current.length
        }
      }
    });
  });

  return {
    summary: {
      added: diff.added.length,
      modified: diff.modified.length,
      renamed: diff.renamed.length,
      deleted: diff.deleted.length,
      totalIndexed: diff.current.length
    }
  };
}

function buildActivities(diff: ScanDiff, diskId: string, scanJobId: string): Prisma.DiskActivityCreateManyInput[] {
  return [
    ...diff.added.map((node) => ({
      diskId,
      scanJobId,
      activityType: ActivityType.ADDED,
      path: node.fullPath,
      details: {
        name: node.name,
        entryType: node.entryType,
        size: node.size?.toString() ?? null,
        modifiedAt: node.modifiedAt?.toISOString() ?? null
      }
    })),
    ...diff.modified.map((change) => ({
      diskId,
      scanJobId,
      activityType: ActivityType.MODIFIED,
      path: change.after.fullPath,
      details: {
        previousModifiedAt: change.before.modifiedAt?.toISOString() ?? null,
        modifiedAt: change.after.modifiedAt?.toISOString() ?? null,
        previousSize: change.before.size?.toString() ?? null,
        size: change.after.size?.toString() ?? null
      }
    })),
    ...diff.renamed.map((change) => ({
      diskId,
      scanJobId,
      activityType: ActivityType.RENAMED,
      path: change.after.fullPath,
      previousPath: change.before.fullPath,
      details: {
        inode: change.after.inode,
        fingerprint: change.after.fingerprint
      }
    })),
    ...diff.deleted.map((entry) => ({
      diskId,
      scanJobId,
      activityType: ActivityType.DELETED,
      path: entry.fullPath,
      details: {
        name: entry.name,
        entryType: entry.entryType
      }
    }))
  ];
}

function mapNodeToCreate(diskId: string, node: ScannedNode): Prisma.FileEntryUncheckedCreateInput {
  return {
    diskId,
    entryType: node.entryType,
    name: node.name,
    relativePath: node.relativePath,
    fullPath: node.fullPath,
    extension: node.extension,
    size: node.size,
    modifiedAt: node.modifiedAt,
    inode: node.inode,
    fingerprint: node.fingerprint,
    metadata: node.metadata,
    deletedAt: null,
    parentId: null
  };
}

function mapNodeToUpdate(node: Omit<ScannedNode, 'parentRelativePath'>): Prisma.FileEntryUncheckedUpdateInput {
  return {
    entryType: node.entryType,
    name: node.name,
    relativePath: node.relativePath,
    fullPath: node.fullPath,
    extension: node.extension,
    size: node.size,
    modifiedAt: node.modifiedAt,
    inode: node.inode,
    fingerprint: node.fingerprint,
    metadata: node.metadata,
    deletedAt: null,
    parentId: null
  };
}

function nodeWithoutParent(node: ScannedNode) {
  const { parentRelativePath: _parentRelativePath, ...rest } = node;
  return rest;
}

function hasEntryChanged(existing: FileEntry, node: ScannedNode) {
  return (
    existing.name !== node.name ||
    existing.entryType !== node.entryType ||
    existing.extension !== node.extension ||
    String(existing.size ?? '') !== String(node.size ?? '') ||
    existing.modifiedAt?.getTime() !== node.modifiedAt?.getTime() ||
    existing.fingerprint !== node.fingerprint
  );
}

function buildUniqueLookup<T>(entries: T[], accessor: (value: T) => string | null | undefined) {
  const counts = new Map<string, number>();
  for (const entry of entries) {
    const key = accessor(entry);
    if (!key) continue;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }

  const unique = new Map<string, T>();
  for (const entry of entries) {
    const key = accessor(entry);
    if (!key) continue;
    if (counts.get(key) === 1) {
      unique.set(key, entry);
    }
  }

  return unique;
}

function buildFingerprint(params: {
  entryType: EntryType;
  extension: string | null;
  size: bigint | null;
  modifiedAt: Date | null;
  name: string;
}) {
  if (params.entryType === EntryType.FILE) {
    return [params.entryType, params.extension ?? '', params.size?.toString() ?? '', params.modifiedAt?.getTime() ?? ''].join(':');
  }

  return [params.entryType, params.name.toLowerCase(), params.modifiedAt?.getTime() ?? ''].join(':');
}

function normalizePath(value: string) {
  return value.split(path.sep).filter(Boolean).join('/');
}
