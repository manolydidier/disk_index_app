'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { RefreshCcw } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';

export function ScanButton({ diskId, scanType = 'DIFFERENTIAL' }: { diskId: string; scanType?: 'FULL' | 'DIFFERENTIAL' }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleScan() {
    setLoading(true);
    try {
      const response = await fetch(`/api/disks/${diskId}/scan`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scanType })
      });
      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Scan impossible');
      }
      toast.success(`Scan ${scanType === 'FULL' ? 'complet' : 'différentiel'} terminé.`);
      router.refresh();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Scan impossible');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button onClick={handleScan} disabled={loading} variant={scanType === 'FULL' ? 'default' : 'outline'}>
      <RefreshCcw className="h-4 w-4" />
      {loading ? 'Scan en cours...' : scanType === 'FULL' ? 'Scan complet' : 'Scan différentiel'}
    </Button>
  );
}
