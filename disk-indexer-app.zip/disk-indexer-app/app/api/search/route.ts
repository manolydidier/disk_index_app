import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export const runtime = 'nodejs';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q')?.trim();
  const diskId = searchParams.get('diskId')?.trim() || undefined;
  const type = searchParams.get('type')?.trim() || undefined;

  if (!query) {
    return NextResponse.json([]);
  }

  const entries = await prisma.fileEntry.findMany({
    where: {
      deletedAt: null,
      diskId,
      entryType: type === 'file' ? 'FILE' : type === 'folder' ? 'FOLDER' : undefined,
      OR: [
        { name: { contains: query, mode: 'insensitive' } },
        { fullPath: { contains: query, mode: 'insensitive' } },
        { extension: { contains: query, mode: 'insensitive' } }
      ]
    },
    include: {
      disk: {
        select: {
          id: true,
          code: true,
          name: true,
          status: true
        }
      }
    },
    orderBy: [{ name: 'asc' }],
    take: 200
  });

  return NextResponse.json(
    entries.map((entry) => ({
      id: entry.id,
      name: entry.name,
      fullPath: entry.fullPath,
      extension: entry.extension,
      entryType: entry.entryType,
      modifiedAt: entry.modifiedAt?.toISOString() ?? null,
      size: entry.size?.toString() ?? null,
      disk: entry.disk
    }))
  );
}
