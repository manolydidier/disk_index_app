'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

type Props = {
  disk?: {
    id: string;
    code: string;
    name: string;
    rootPath: string;
    description: string | null;
    status: 'ACTIVE' | 'INACTIVE' | 'DISCONNECTED';
    isEnabled: boolean;
  };
};

export function DiskForm({ disk }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: disk?.name ?? '',
    rootPath: disk?.rootPath ?? '',
    description: disk?.description ?? '',
    status: disk?.status ?? 'ACTIVE',
    code: disk?.code ?? ''
  });

  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);

    try {
      const response = await fetch(disk ? `/api/disks/${disk.id}` : '/api/disks', {
        method: disk ? 'PATCH' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          code: form.code || undefined
        })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error?.formErrors?.join(', ') || data.error || 'Enregistrement impossible');
      }

      toast.success(disk ? 'Disque mis à jour.' : 'Disque ajouté.');
      router.refresh();
      if (!disk) {
        setForm({ name: '', rootPath: '', description: '', status: 'ACTIVE', code: '' });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Une erreur est survenue');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{disk ? 'Modifier le disque' : 'Ajouter un disque'}</CardTitle>
        <CardDescription>
          {disk ? 'Mettez à jour le nom, le point de montage ou le statut.' : 'Enregistrez un nouveau disque physique ou monté sur le serveur.'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form className="grid gap-4 md:grid-cols-2" onSubmit={onSubmit}>
          <div className="space-y-2">
            <Label htmlFor="code">Code disque</Label>
            <Input id="code" placeholder="DB0005" value={form.code} onChange={(e) => setForm((c) => ({ ...c, code: e.target.value }))} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Nom</Label>
            <Input id="name" required value={form.name} onChange={(e) => setForm((c) => ({ ...c, name: e.target.value }))} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="rootPath">Point de montage / chemin racine</Label>
            <Input id="rootPath" required placeholder="/mnt/DB0001" value={form.rootPath} onChange={(e) => setForm((c) => ({ ...c, rootPath: e.target.value }))} />
          </div>
          <div className="space-y-2 md:col-span-2">
            <Label htmlFor="description">Description</Label>
            <Textarea id="description" value={form.description} onChange={(e) => setForm((c) => ({ ...c, description: e.target.value }))} />
          </div>
          <div className="space-y-2">
            <Label>Statut</Label>
            <Select value={form.status} onValueChange={(value) => setForm((c) => ({ ...c, status: value as typeof form.status }))}>
              <SelectTrigger>
                <SelectValue placeholder="Choisir un statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ACTIVE">Actif</SelectItem>
                <SelectItem value="INACTIVE">Inactif</SelectItem>
                <SelectItem value="DISCONNECTED">Non connecté</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end">
            <Button type="submit" disabled={loading} className="w-full md:w-auto">
              {loading ? 'Enregistrement...' : disk ? 'Mettre à jour' : 'Créer le disque'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
