import { DiskStatus } from '@prisma/client';
import { z } from 'zod';

export const diskCreateSchema = z.object({
  code: z.string().regex(/^DB\d{4,}$/).optional(),
  name: z.string().min(2).max(120),
  rootPath: z.string().min(2).max(500),
  description: z.string().max(1000).optional().nullable(),
  status: z.nativeEnum(DiskStatus).default(DiskStatus.ACTIVE)
});

export const diskUpdateSchema = diskCreateSchema.partial().extend({
  isEnabled: z.boolean().optional()
});

export const scanRequestSchema = z.object({
  scanType: z.enum(['FULL', 'DIFFERENTIAL']).default('DIFFERENTIAL')
});

export const activityAcknowledgeSchema = z
  .object({
    ids: z.array(z.string()).optional(),
    diskId: z.string().optional()
  })
  .refine((value) => Boolean(value.diskId || value.ids?.length), {
    message: 'Vous devez fournir un diskId ou une liste d'identifiants.'
  });
