import { NextResponse } from 'next/server';
import { ScanType } from '@prisma/client';
import { runDiskScan } from '@/lib/scanner';
import { scanRequestSchema } from '@/lib/validators';

export const runtime = 'nodejs';

export async function POST(request: Request, context: { params: Promise<{ diskId: string }> }) {
  const { diskId } = await context.params;
  const payload = await request.json().catch(() => ({}));
  const parsed = scanRequestSchema.safeParse(payload);

  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  try {
    const result = await runDiskScan(diskId, parsed.data.scanType === 'FULL' ? ScanType.FULL : ScanType.DIFFERENTIAL);
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Le scan a échoué.' },
      { status: 500 }
    );
  }
}
